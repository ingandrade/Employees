<?php $__env->startSection('content'); ?>

<div  class="container-fluid">
    <div class="row page-titles align-items-center">
        <div class="col-12  margin-content font-title-content">
            Create Companies
        </div>
    </div>  

    <div class="row">
        <div class="col">
            <div class="card">
                <div class="card-body">
                    <div class="row">
                        <div class="col-12 col-sm-12 col-md-2 col-lg-2">
                            <?php if($comp->logo): ?>
                                <img src="<?php echo e(asset('storage/').'/'.$comp->logo); ?>" alt="" class="img-fluid">
                            <?php else: ?>
                                <img src="<?php echo e(asset('img/edificio.jpg')); ?>" alt="" class="img-fluid">
                            <?php endif; ?>
                        </div>
                        <div class="col-12 col-sm-12 col-md-10 col-lg-10">
                            <h2><?php echo e($comp->name); ?></h2>
                            <div><?php echo e($comp->email); ?></div>
                            <div><?php echo e($comp->webside); ?></div>
                            <div class="text-right">
                                <a href="<?php echo e(route('companies.index')); ?>" class="btn btn-success">
                                    Preview
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>  
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Test pruebas empresas\employees\resources\views/companies/show.blade.php ENDPATH**/ ?>