<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
  <?php echo $__env->make("_partials/head", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body class="<?php echo $__env->yieldContent('tags'); ?> <?php echo e(Request::path() == 'login'  ? 'img-background' : 'mini-sidebar'); ?> ">

  <?php echo $__env->make("_partials/header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  

  <?php echo $__env->make("_partials/menubarLat", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <?php echo $__env->yieldContent('breadcrumbs'); ?>
  


  <div class="<?php echo e(Auth::check() ? 'page-wrapper' : 'h-100'); ?>" id="main-wrapper">
    <?php if(session('info')): ?>
      <div class="container">
          <div class="row">
              <div class="col  mt-1align-self-end">
                  <div class="alert alert-success">
                      <?php echo e(session('info')); ?>

                  </div>
              </div>
          </div>
      </div>
    <?php endif; ?>
    <?php echo $__env->yieldContent('content'); ?>
  </div>

  <?php echo $__env->make("_partials/footer", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  

  <?php echo $__env->make("_partials/tail", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>
</html><?php /**PATH C:\Test pruebas empresas\employees\resources\views/layouts/master.blade.php ENDPATH**/ ?>