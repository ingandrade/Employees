<?php $__env->startSection('content'); ?>

<div  class="container-fluid">
    <div class="row page-titles align-items-center">
        <div class="col-12  margin-content font-title-content">
            Employees
        </div>
    </div>  

    <div class="row">
        <div class="col">
            <div class="card">
                <div class="card-body">
                    <table class="table table-striped table-hover">
                        <thead>
                            <tr>
                                <th width="10px">ID</th>
                                <th>Firstname</th>
                                <th>Lastname</th>
                                <th>companie</th>
                                <th>Email</th>
                                <th>phone</th>
                                <th colspan="3">&nbsp;</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $emp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($emp->id); ?></td>
                                <td><?php echo e($emp->firstname); ?></td>
                                <td><?php echo e($emp->lastname); ?></td>
                                <td></td>
                                <td><?php echo e($emp->email); ?></td>
                                <td><?php echo e($emp->phone); ?></td>
                                <td width="10px">
                                    <a href="<?php echo e(route('employees.show', $emp->id)); ?>" class="btn btn-sm btn-default">
                                        <button class="btn btn-sm btn-success">
                                        Ver
                                        </button>
                                    </a>
                                </td>
                                <td width="10px">
                                    <a href="<?php echo e(route('employees.edit', $emp->id)); ?>" class="btn btn-sm btn-default">
                                        <button class="btn btn-sm btn-warning">
                                            Editar
                                        </button>
                                    </a>
                                </td>
                                <td width="10px">
                                    <?php echo Form::open(['route' => ['employees.destroy', $emp->id], 'method' => 'DELETE']); ?>

                                        <button class="btn btn-sm btn-danger" style="margin-top:4px">
                                            Eliminar
                                        </button>                           
                                    <?php echo Form::close(); ?>

                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>   
                    </table>  
                    <div class="text-center col">
                        <?php echo e($employees->render()); ?> 
                    </div>  	
                </div>
            </div>
        </div>
    </div>  
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Test pruebas empresas\employees\resources\views/employees/index.blade.php ENDPATH**/ ?>