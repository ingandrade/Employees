<?php $__env->startSection('content'); ?>

<div  class="container-fluid">
    <div class="row page-titles align-items-center">
        <div class="col-12  margin-content font-title-content">
            Employee
        </div>
    </div>  

    <div class="row">
        <div class="col">
            <div class="card">
                <div class="card-body">
                    <div class="row">
                        <div class="col-12 col-sm-12 col-md-2 col-lg-2">
                            
                            <img src="<?php echo e(asset('img/perfil.png')); ?>" alt="" class="img-fluid">
                          
                        </div>
                        <div class="col-12 col-sm-12 col-md-10 col-lg-10">
                            <h2><?php echo e($emp->firstname); ?></h2>
                            <h2><?php echo e($emp->lastname); ?></h2>
                            <div><?php echo e($emp->email); ?></div>
                            <div><?php echo e($emp->phone); ?></div>
                            <h2><?php echo e($emp->companies); ?></h2>
                            <div class="text-right">
                                <a href="<?php echo e(route('employees.index')); ?>" class="btn btn-success">
                                    Preview
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>  
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Test pruebas empresas\employees\resources\views/employees/show.blade.php ENDPATH**/ ?>