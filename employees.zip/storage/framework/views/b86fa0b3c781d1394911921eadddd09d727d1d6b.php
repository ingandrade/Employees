<?php $__env->startSection('tail'); ?>
<?php echo $__env->yieldContent('custom_script'); ?>

<?php if(Auth::check()): ?>
    <?php echo Html::script('js/jquery.slimscroll.js'); ?>

    <?php echo Html::script('js/waver.js'); ?>

    <?php echo Html::script('js/sidebarmenu.js'); ?>

    <?php echo Html::script('js/sticky-kit.min.js'); ?>

    <?php echo Html::script('js/jquery.sparkline.min.js'); ?>

    <?php echo Html::script('js/custom.min.js'); ?>

<?php endif; ?>

<?php echo $__env->yieldSection(); ?><?php /**PATH C:\Test pruebas empresas\employees\resources\views/_partials/tail.blade.php ENDPATH**/ ?>