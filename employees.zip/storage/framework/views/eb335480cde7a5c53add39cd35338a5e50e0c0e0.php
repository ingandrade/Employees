<header class="topbar is_stuck position-navbar-fixed">

<?php $__env->startSection('header'); ?>
  
    <?php if(Auth::check()): ?> 
        <?php echo $__env->make('_partials.menubar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>

<?php echo $__env->yieldSection(); ?>
</header>
<?php if(Auth::check()): ?>
    <div class="div-master"></div>
<?php endif; ?><?php /**PATH C:\Test pruebas empresas\employees\resources\views/_partials/header.blade.php ENDPATH**/ ?>