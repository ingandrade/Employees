<?php $__env->startSection('content'); ?>

<div  class="container-fluid">
    <div class="row page-titles align-items-center">
        <div class="col-12  margin-content font-title-content">
            Dashboard
        </div>
    </div>  
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Test pruebas empresas\employees\resources\views/home.blade.php ENDPATH**/ ?>